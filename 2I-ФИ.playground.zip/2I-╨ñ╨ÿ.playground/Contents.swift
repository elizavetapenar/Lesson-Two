import Foundation

// Задание №1. Написать функцию, которая определяет, четное число или нет.
var filteredNumber = 3
func filter (nums: Int) -> Bool {
    var result = Bool()
        if nums % 2 == 0{
            result = true
        } else {
            result = false
        }
     return result
}
let result = filter (nums: filteredNumber)
print(result)

// Задание №2. Написать функцию, которая определяет, делится ли число без остатка на 3.
var number = 9
func sorting (num: Int) -> Bool {
    var outcome = Bool()
    if num % 3 == 0 {
        outcome = true
    } else {
        outcome = false
    }
    return outcome
}

let outcome = sorting(num: number)
print(outcome)

// Задание №3. Создать возрастающий массив из 100 чисел.
var emptyArray: [Int] = []
for numbers in 1...100 {
    emptyArray.append(numbers)
}
print (emptyArray)

// Задание №4. Удалить из этого массива все четные числа и все числа, которые делятся на 3.
var filteredArray: [Int] = []
for num in emptyArray {
    if num % 2 == 0 || num % 3 == 0 {
        filteredArray.append(num)
    }
}
print (filteredArray)

// Задание №5*. Написать функцию, которая добавляет в массив новое число Фибоначчи, и добавить при помощи нее 100 элементов.
func adds (values: Int) -> [Double] {
    var fibonachi: [Double] = [1, 1]
    (2...values).forEach {i in
        fibonachi.append(fibonachi[i - 1] + fibonachi [i - 2])
    }
    return fibonachi
}

print(adds(values: 100))
